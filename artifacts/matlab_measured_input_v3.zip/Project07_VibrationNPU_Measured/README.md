# 실측 전용 MATLAB·Simulink 2차 패키지

현재 폴더를 이 파일과 RUN_MEASURED_STUDY.m이 있는 곳으로 바꾸고 실행하세요.

```matlab
RUN_MEASURED_STUDY
```

실측 진동 6개 run(23,040개 X축 원시값)과 모터 기록 5개가 원본 그대로 들어 있습니다.
추가 다운로드나 Python 실행 없이 MATLAB 분석을 시작할 수 있습니다.
Simulink가 있으면 reports/measured/에 진동과 모터 재생용 .slx 두 개를 생성하고 검증합니다.
Simulink가 없으면 MATLAB 분석만 실행하고 UNAVAILABLE로 기록합니다.

3D 그림은 실제 프레임 스펙트럼입니다. Y/Z·변위·자세는 측정되어 있지 않습니다.
기존 가정 기반 6자유도 모델 소스/입력은 이 패키지에 없습니다.
MATLAB/Simulink 실행 확인은 아직 수행하지 않았습니다.
기존 source 전체를 위한 FPGA build gate 패키지가 아니므로 .pass 파일을 만들지 않습니다.

자세한 설명: [실측 가이드](docs/MATLAB_SIMULINK_MEASURED.md).
기록된 Python 재현 결과: reports/measured_offline/.
