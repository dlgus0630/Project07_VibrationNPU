# 실측 전용 2차 경로 검증 기록

## 실행한 검사

- MISS_HIT 0.9.44: `RUN_MEASURED_STUDY.m` 및 `matlab/measured/`의 MATLAB 파일 총 7개 문법 검사 통과.
- `python3 -m unittest discover -s tools -p test_measured_replay.py -q`: 21개 검사 통과.
  실측 원본/metadata 해시, 완전한 frame, 순서·중복·시간 간격·run 분리·실측 export 일치를 검사한다.
  잘못된 파일 검출 시험은 원본을 복제한 임시 디렉터리에서만 수행한다.
- 실제 원본과 일치하는 기존 hardware Golden 입력 16개의 특징·hidden·logits·class 일치.
- 원본 진동 6 run × 60 frame × 64 sample = 23,040개 값을 그대로 사용.
- 기존 학습 split: 240/240. 기존 검증 split: 118/120, confusion `[[58,2],[0,60]]`.
  오분류는 `normal_50_03`의 window 0, 50이다. 새로운 독립 시험 결과가 아니다.
- 모터 원본 5개 CSV 총 19,381개 기록: 정수/상태/counter/명목 시간/Q12 단위 환산 검사 통과.
- capture CSV reader의 파일 닫힘을 수정했고 기존 `test_capture_dataset.py` 회귀 검사도 통과.
  이 기존 검사에서 사용하는 임시 fixture는 분석 입력이나 배포 데이터에 포함하지 않는다.
- 배포 ZIP을 임시 폴더에 풀어 원본 해시, 6개 진동 run 및 5개 모터 기록 재검사 통과.

## 아직 실행하지 않은 검사

이 환경에는 MATLAB/Simulink 실행기가 없다. 새 MATLAB 함수의 실제 실행, `.slx` 생성,
Simulink compile/`sim`, MATLAB waterfall 렌더링은 미검증이다. Python 출력 그림은 MATLAB
실행 화면이 아니다. ZIP에는 새 `.slx` 대신 원본 실측값과 모델 생성/실행 코드가 들어 있다.

MATLAB에서 `RUN_MEASURED_STUDY`를 실행하면 원본 검증과 분석을 수행하고, Simulink가 있으면
실측 진동 모델과 모터 telemetry 모델을 생성한다. 진동 raw/dt/metadata/FFT/NPU와 모터 원본
채널의 정확한 재생 일치가 검사된다. 결과는 `reports/measured/measured_run_status.json`에
기록된다. 기존 FPGA의 `matlab.pass`/`sim.pass`는 만들거나 갱신하지 않는다.

## 해석 범위

X축만 기록되어 있어 XYZ 운동이나 6자유도 변위를 복원하지 않는다. 진동 프레임 사이 공백을
채우지 않으며, 모터와 진동의 서로 다른 측정 세션을 동시 계측으로 연결하지 않는다.
Python 그림은 프레임별 진폭 스펙트럼, MATLAB 그림은 프레임별 Hann PSD다.
