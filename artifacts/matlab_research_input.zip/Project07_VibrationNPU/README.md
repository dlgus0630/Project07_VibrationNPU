# MATLAB·Simulink 6자유도 연구 패키지

압축을 풀고 RUN_RESEARCH_STUDY.m이 있는 폴더에서 실행합니다.

```matlab
RUN_RESEARCH_STUDY('ripple')
```

질량·강성·감쇠·가진력은 연구용 가정값이며 실측 XYZ가 아닙니다.
이 패키지는 연구 모델과 기존 정수 Golden 소스, 연구 설명서를 제공합니다.
공식 Golden 검증은 RUN_MATLAB_CHECKS, 연구 전체 시나리오는
RUN_RESEARCH_STUDY('all')로 실행합니다. 새 MATLAB·Simulink 실행 검증은 아직 남아 있습니다.

실측 센서 CSV와 모터 telemetry 원본은 이 ZIP에 포함되지 않습니다.
실측 재현에는 별도 matlab_measured_input.zip을 사용하고 RUN_MEASURED_STUDY를 실행합니다.
소스 지문을 유지하기 위해 실측 함수와 EXPORT_README_FIGURES 소스도 함께 들어 있지만,
그 함수들은 이 연구 ZIP만으로 실행할 수 없습니다. README의 전체 그림 내보내기는
실측 원본과 모든 소스가 있는 전체 저장소에서 수행해야 합니다.

- [6자유도 연구 가이드](docs/MATLAB_SIMULINK_RESEARCH.md)
- [한국어 코드 각주 안내](docs/STUDY_CODE_NOTES.md)
- Python 독립 수치 참조: reports/research_offline/ (MATLAB 실행 결과가 아님)
