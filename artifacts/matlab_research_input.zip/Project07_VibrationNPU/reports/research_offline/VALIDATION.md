# 새 연구 코드 검증 상태

- MATLAB 정적 문법 검사: MISS_HIT 0.9.44, 새 `.m` 파일 13개, 오류 없음.
- Python 수치 참조: `tools/check_research_reference.py`, 독립 물리식 검사 29개 통과.
- 확인 범위: 행렬 대칭/정부호, 안정성, 정적 평형, 센서 지렛팔·중력, 자유 감쇠,
  정확한 ZOH 합성, 시간 간격 수렴, PSD 정규화, 네 시나리오의 유한 응답.
- 시간 간격 절반 감소 시 오차비: 약 0.500672.
- Python 보고서에 검증 당시 MATLAB 소스와 실행 진입점 SHA256을 기록했다.
- Python 미리보기의 형상과 신호는 연구용 가정값으로 계산했다.
- **MATLAB·Simulink 실행/컴파일 및 MATLAB 3D 렌더링은 미실행이다.**
  정적 검사와 독립 Python 계산이 MATLAB 실행을 대체하지 않는다.
- 새 `.slx`는 `RUN_RESEARCH_STUDY('ripple')`을 MATLAB/Simulink에서 실행할 때 생성된다.
- 기존 `matlab.pass`/`sim.pass`를 생성하거나 갱신하지 않았다.

MATLAB에서는 자체 물리 검증, 제공된 정수 Golden 검사, MATLAB/Simulink 상태·센서·프레임·
특징·hidden·logits·판정·안전 정책 비교가 실제로 실행된다. 연구 상태는
`reports/research/research_run_status.json`에서 확인한다.
